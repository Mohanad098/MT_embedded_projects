#include "Os.h"

int main(void)
{
    /* Start the Os */
    Os_start();
}
